const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const rooms = new Map();

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, app: "BalkanSync" }));

function makeCode() {
  let code;
  do { code = crypto.randomBytes(3).toString("hex").toUpperCase(); } while (rooms.has(code));
  return code;
}
function parseYouTubeId(input) {
  if (typeof input !== "string") return null;
  const s = input.trim();
  if (/^[A-Za-z0-9_-]{11}$/.test(s)) return s;
  const m = s.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:[^#]*&)?v=|embed\/|shorts\/))([A-Za-z0-9_-]{11})/);
  return m ? m[1] : null;
}
function snapshot(r) {
  let time = r.time;
  if (r.playing) time += (Date.now() - r.updatedAt) / 1000;
  return { code:r.code, videoId:r.videoId, playing:r.playing, time, members:r.members.size, hostId:r.host };
}
function broadcastState(r) { io.to(r.code).emit("state", snapshot(r)); }

io.on("connection", socket => {
  socket.on("create-room", ack => {
    const code = makeCode();
    const r = { code, host:socket.id, members:new Set([socket.id]), videoId:null, playing:false, time:0, updatedAt:Date.now() };
    rooms.set(code, r); socket.join(code); socket.data.room=code;
    if (typeof ack === "function") ack({ ok:true, state:snapshot(r), host:true });
    broadcastState(r);
  });

  socket.on("join-room", (data, ack) => {
    const code = String(data?.code || "").trim().toUpperCase();
    const r = rooms.get(code);
    if (!r) return typeof ack === "function" && ack({ok:false,error:"Room code nahi mila. Code check karein."});
    if (socket.data.room && socket.data.room !== code) {
      const old = rooms.get(socket.data.room);
      if (old) old.members.delete(socket.id);
      socket.leave(socket.data.room);
    }
    r.members.add(socket.id); socket.join(code); socket.data.room=code;
    if (typeof ack === "function") ack({ok:true,state:snapshot(r),host:r.host===socket.id});
    broadcastState(r);
  });

  socket.on("set-video", (data, ack) => {
    const r=rooms.get(socket.data.room);
    if (!r) return typeof ack==="function" && ack({ok:false,error:"Pehle room banayein ya join karein."});
    if (r.host!==socket.id) return typeof ack==="function" && ack({ok:false,error:"Video sirf room host badal sakta hai."});
    const id=parseYouTubeId(data?.url);
    if (!id) return typeof ack==="function" && ack({ok:false,error:"Valid YouTube video link paste karein."});
    r.videoId=id; r.time=0; r.playing=false; r.updatedAt=Date.now();
    io.to(r.code).emit("video", {videoId:id, time:0, playing:false});
    broadcastState(r);
    if (typeof ack==="function") ack({ok:true});
  });

  socket.on("control", data => {
    const r=rooms.get(socket.data.room);
    if (!r || r.host!==socket.id || !r.videoId) return;
    const action=data?.action;
    if (!["play","pause","seek"].includes(action)) return;
    const time=Number(data?.time);
    if (Number.isFinite(time)) r.time=Math.max(0,time);
    r.playing=action==="play" ? true : action==="pause" ? false : r.playing;
    r.updatedAt=Date.now();
    socket.to(r.code).emit("control", {action,time:r.time,playing:r.playing,updatedAt:r.updatedAt});
    broadcastState(r);
  });

  socket.on("sync-request", () => {
    const r=rooms.get(socket.data.room);
    if (r) socket.emit("state", snapshot(r));
  });

  socket.on("disconnect", () => {
    const code=socket.data.room, r=rooms.get(code);
    if (!r) return;
    r.members.delete(socket.id);
    if (r.host===socket.id) {
      if (r.members.size) {
        r.host=r.members.values().next().value;
        io.to(code).emit("host-changed", {hostId:r.host});
      } else { rooms.delete(code); return; }
    }
    broadcastState(r);
  });
});

server.listen(PORT, "0.0.0.0", () => console.log(`BalkanSync listening on ${PORT}`));