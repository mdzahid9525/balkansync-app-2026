# BalkanSync

A mobile-friendly watch-together web app. One person creates a room, shares the 6-character code, and the other phone joins. The host loads a YouTube link; host play/pause/seek events are sent to the room through Socket.IO.

## Deploy on Render (phone-friendly)
1. Upload these project files to a GitHub repository, preserving the `public/` folder.
2. In Render, create a **New Web Service** and connect that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Deploy, then open the service URL on both phones.

The server keeps room state in memory, so rooms disappear when the server restarts. This is a prototype, not a native APK. Browser autoplay rules mean the second phone may need one tap to start playback; exact frame-perfect synchronization is not guaranteed. Some YouTube videos disallow embedded playback.
